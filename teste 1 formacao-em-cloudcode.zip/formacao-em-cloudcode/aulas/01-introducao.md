# Aula 1 – Introdução ao Claude Code

O Claude Code é uma ferramenta que roda no terminal e ajuda a escrever,
editar e organizar código e arquivos do seu projeto.

## Anotações

- 
