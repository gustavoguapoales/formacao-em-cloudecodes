# Aula 2 – Primeiros comandos

- `claude` – abre o Claude Code na pasta atual
- `/help` – mostra os comandos disponíveis
- `/clear` – limpa a conversa

## Anotações

- 
