# Formação em Claude Code

Repositório de teste para acompanhar a formação em Claude Code.

## Estrutura

- `aulas/` – anotações de cada aula
- `exercicios/` – exercícios práticos
- `CLAUDE.md` – instruções que o Claude Code lê ao abrir este projeto

## Status

- [x] Repositório criado
- [ ] Aula 1 concluída
- [ ] Aula 2 concluída
