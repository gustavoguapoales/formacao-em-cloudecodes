# Exercício de teste

1. Abra o terminal nesta pasta.
2. Rode `claude`.
3. Peça: "Crie um arquivo hello.py que imprime Olá, mundo".
4. Confira se o arquivo foi criado.
