# Instruções do projeto

Este é um projeto de estudo. Responda sempre em português do Brasil,
explique de forma simples e passo a passo.
